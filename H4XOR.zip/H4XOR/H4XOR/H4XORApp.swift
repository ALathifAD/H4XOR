//
//  H4XORApp.swift
//  H4XOR
//
//  Created by Lathif A.D on 29/07/24.
//

import SwiftUI

@main
struct H4XORApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
